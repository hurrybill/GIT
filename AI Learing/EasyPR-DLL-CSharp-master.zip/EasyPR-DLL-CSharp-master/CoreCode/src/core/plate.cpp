#include "easypr/core/plate.hpp"

/*! \namespace easypr
Namespace where all the C++ EasyPR functionality resides
*/
namespace easypr {

CPlate::CPlate() { bColored = true; } 

} /*! \namespace easypr*/