﻿namespace test_interface
{
    partial class SinglePic
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.char0 = new System.Windows.Forms.PictureBox();
            this.char1 = new System.Windows.Forms.PictureBox();
            this.char2 = new System.Windows.Forms.PictureBox();
            this.char3 = new System.Windows.Forms.PictureBox();
            this.char4 = new System.Windows.Forms.PictureBox();
            this.char5 = new System.Windows.Forms.PictureBox();
            this.char6 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.char7 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出程序ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.分步演示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车牌定位ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.字符分割ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.模式切换ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.单图测试ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.批量测试ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.训练模型ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sVM训练ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNN训练ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成样本ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sVM训练样本生成ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNN训练样本ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于本系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.char6)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.char7)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(112, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 36);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(42, 114);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(400, 300);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // char0
            // 
            this.char0.Location = new System.Drawing.Point(16, 34);
            this.char0.Name = "char0";
            this.char0.Size = new System.Drawing.Size(30, 30);
            this.char0.TabIndex = 5;
            this.char0.TabStop = false;
            // 
            // char1
            // 
            this.char1.Location = new System.Drawing.Point(59, 34);
            this.char1.Name = "char1";
            this.char1.Size = new System.Drawing.Size(30, 30);
            this.char1.TabIndex = 6;
            this.char1.TabStop = false;
            // 
            // char2
            // 
            this.char2.Location = new System.Drawing.Point(102, 34);
            this.char2.Name = "char2";
            this.char2.Size = new System.Drawing.Size(30, 30);
            this.char2.TabIndex = 7;
            this.char2.TabStop = false;
            // 
            // char3
            // 
            this.char3.Location = new System.Drawing.Point(145, 34);
            this.char3.Name = "char3";
            this.char3.Size = new System.Drawing.Size(30, 30);
            this.char3.TabIndex = 8;
            this.char3.TabStop = false;
            // 
            // char4
            // 
            this.char4.Location = new System.Drawing.Point(188, 34);
            this.char4.Name = "char4";
            this.char4.Size = new System.Drawing.Size(30, 30);
            this.char4.TabIndex = 9;
            this.char4.TabStop = false;
            // 
            // char5
            // 
            this.char5.Location = new System.Drawing.Point(231, 34);
            this.char5.Name = "char5";
            this.char5.Size = new System.Drawing.Size(30, 30);
            this.char5.TabIndex = 10;
            this.char5.TabStop = false;
            // 
            // char6
            // 
            this.char6.Location = new System.Drawing.Point(274, 34);
            this.char6.Name = "char6";
            this.char6.Size = new System.Drawing.Size(30, 30);
            this.char6.TabIndex = 11;
            this.char6.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(23, 82);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(437, 348);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "车牌图像定位图";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(495, 82);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(355, 84);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "车牌图像";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.char7);
            this.groupBox3.Controls.Add(this.char0);
            this.groupBox3.Controls.Add(this.char1);
            this.groupBox3.Controls.Add(this.char2);
            this.groupBox3.Controls.Add(this.char3);
            this.groupBox3.Controls.Add(this.char6);
            this.groupBox3.Controls.Add(this.char4);
            this.groupBox3.Controls.Add(this.char5);
            this.groupBox3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(495, 200);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(355, 84);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "车牌字符分割图";
            // 
            // char7
            // 
            this.char7.Location = new System.Drawing.Point(317, 34);
            this.char7.Name = "char7";
            this.char7.Size = new System.Drawing.Size(30, 30);
            this.char7.TabIndex = 12;
            this.char7.TabStop = false;
            this.char7.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(495, 330);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(355, 84);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "车牌识别结果";
            // 
            // textBox1
            // 
            this.textBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 25F);
            this.textBox1.Location = new System.Drawing.Point(33, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(297, 51);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.分步演示ToolStripMenuItem,
            this.模式切换ToolStripMenuItem,
            this.训练模型ToolStripMenuItem,
            this.生成样本ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(884, 25);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开ToolStripMenuItem,
            this.退出程序ToolStripMenuItem});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.文件ToolStripMenuItem.Text = "文件";
            // 
            // 打开ToolStripMenuItem
            // 
            this.打开ToolStripMenuItem.Name = "打开ToolStripMenuItem";
            this.打开ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.打开ToolStripMenuItem.Text = "打开文件";
            this.打开ToolStripMenuItem.Click += new System.EventHandler(this.打开ToolStripMenuItem_Click);
            // 
            // 退出程序ToolStripMenuItem
            // 
            this.退出程序ToolStripMenuItem.Name = "退出程序ToolStripMenuItem";
            this.退出程序ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.退出程序ToolStripMenuItem.Text = "退出程序";
            this.退出程序ToolStripMenuItem.Click += new System.EventHandler(this.退出程序ToolStripMenuItem_Click);
            // 
            // 分步演示ToolStripMenuItem
            // 
            this.分步演示ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.车牌定位ToolStripMenuItem,
            this.字符分割ToolStripMenuItem});
            this.分步演示ToolStripMenuItem.Name = "分步演示ToolStripMenuItem";
            this.分步演示ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.分步演示ToolStripMenuItem.Text = "分步演示";
            this.分步演示ToolStripMenuItem.Click += new System.EventHandler(this.分步演示ToolStripMenuItem_Click);
            // 
            // 车牌定位ToolStripMenuItem
            // 
            this.车牌定位ToolStripMenuItem.Name = "车牌定位ToolStripMenuItem";
            this.车牌定位ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.车牌定位ToolStripMenuItem.Text = "车牌定位";
            this.车牌定位ToolStripMenuItem.Click += new System.EventHandler(this.车牌定位ToolStripMenuItem_Click);
            // 
            // 字符分割ToolStripMenuItem
            // 
            this.字符分割ToolStripMenuItem.Name = "字符分割ToolStripMenuItem";
            this.字符分割ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.字符分割ToolStripMenuItem.Text = "字符分割";
            this.字符分割ToolStripMenuItem.Click += new System.EventHandler(this.字符分割ToolStripMenuItem_Click);
            // 
            // 模式切换ToolStripMenuItem
            // 
            this.模式切换ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.单图测试ToolStripMenuItem,
            this.批量测试ToolStripMenuItem});
            this.模式切换ToolStripMenuItem.Name = "模式切换ToolStripMenuItem";
            this.模式切换ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.模式切换ToolStripMenuItem.Text = "模式切换";
            // 
            // 单图测试ToolStripMenuItem
            // 
            this.单图测试ToolStripMenuItem.Checked = true;
            this.单图测试ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.单图测试ToolStripMenuItem.Name = "单图测试ToolStripMenuItem";
            this.单图测试ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.单图测试ToolStripMenuItem.Text = "单图模式";
            // 
            // 批量测试ToolStripMenuItem
            // 
            this.批量测试ToolStripMenuItem.Name = "批量测试ToolStripMenuItem";
            this.批量测试ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.批量测试ToolStripMenuItem.Text = "批量模式";
            this.批量测试ToolStripMenuItem.Click += new System.EventHandler(this.批量测试ToolStripMenuItem_Click);
            // 
            // 训练模型ToolStripMenuItem
            // 
            this.训练模型ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sVM训练ToolStripMenuItem,
            this.aNN训练ToolStripMenuItem});
            this.训练模型ToolStripMenuItem.Name = "训练模型ToolStripMenuItem";
            this.训练模型ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.训练模型ToolStripMenuItem.Text = "训练模型";
            // 
            // sVM训练ToolStripMenuItem
            // 
            this.sVM训练ToolStripMenuItem.Name = "sVM训练ToolStripMenuItem";
            this.sVM训练ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.sVM训练ToolStripMenuItem.Text = "SVM训练";
            this.sVM训练ToolStripMenuItem.Click += new System.EventHandler(this.sVM训练ToolStripMenuItem_Click);
            // 
            // aNN训练ToolStripMenuItem
            // 
            this.aNN训练ToolStripMenuItem.Name = "aNN训练ToolStripMenuItem";
            this.aNN训练ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.aNN训练ToolStripMenuItem.Text = "ANN训练";
            this.aNN训练ToolStripMenuItem.Click += new System.EventHandler(this.aNN训练ToolStripMenuItem_Click);
            // 
            // 生成样本ToolStripMenuItem
            // 
            this.生成样本ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sVM训练样本生成ToolStripMenuItem,
            this.aNN训练样本ToolStripMenuItem});
            this.生成样本ToolStripMenuItem.Name = "生成样本ToolStripMenuItem";
            this.生成样本ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.生成样本ToolStripMenuItem.Text = "生成样本";
            // 
            // sVM训练样本生成ToolStripMenuItem
            // 
            this.sVM训练样本生成ToolStripMenuItem.Name = "sVM训练样本生成ToolStripMenuItem";
            this.sVM训练样本生成ToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.sVM训练样本生成ToolStripMenuItem.Text = "SVM数据集";
            this.sVM训练样本生成ToolStripMenuItem.Click += new System.EventHandler(this.sVM训练样本生成ToolStripMenuItem_Click);
            // 
            // aNN训练样本ToolStripMenuItem
            // 
            this.aNN训练样本ToolStripMenuItem.Name = "aNN训练样本ToolStripMenuItem";
            this.aNN训练样本ToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.aNN训练样本ToolStripMenuItem.Text = "ANN数据集";
            this.aNN训练样本ToolStripMenuItem.Click += new System.EventHandler(this.aNN训练样本ToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于本系统ToolStripMenuItem});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 关于本系统ToolStripMenuItem
            // 
            this.关于本系统ToolStripMenuItem.Name = "关于本系统ToolStripMenuItem";
            this.关于本系统ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.关于本系统ToolStripMenuItem.Text = "关于本系统";
            // 
            // SinglePic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 491);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SinglePic";
            this.Text = "单图模式 - EasyPR C# 版";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.char6)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.char7)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox char0;
        private System.Windows.Forms.PictureBox char1;
        private System.Windows.Forms.PictureBox char2;
        private System.Windows.Forms.PictureBox char3;
        private System.Windows.Forms.PictureBox char4;
        private System.Windows.Forms.PictureBox char5;
        private System.Windows.Forms.PictureBox char6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 分步演示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 模式切换ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车牌定位ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 字符分割ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 单图测试ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 批量测试ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出程序ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于本系统ToolStripMenuItem;
        private System.Windows.Forms.PictureBox char7;
        private System.Windows.Forms.ToolStripMenuItem 训练模型ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sVM训练ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNN训练ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成样本ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sVM训练样本生成ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNN训练样本ToolStripMenuItem;
    }
}

